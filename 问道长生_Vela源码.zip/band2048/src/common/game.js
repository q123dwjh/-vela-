/**
 * 2048·问道长生 —— 纯逻辑层（不依赖任何系统接口）
 * 16 境界链：凡人→炼气→筑基→金丹→元婴→化神→炼虚→合体→大乘→渡劫
 *            →地仙→天仙→金仙→大罗金仙→道祖→混沌
 * 灵盘支持 4x4（默认）/ 5x4 / 5x5，局内可由「上古遗迹」临时扩展
 * 性能约定：一次滑动只做 1 次数组遍历（移动+合并+锁定递减+刷新显示）
 */

export const REALMS = [
  { v: 1, name: '凡人', short: '凡', lore: '生于尘土，寿不过百' },
  { v: 2, name: '炼气', short: '气', lore: '引气入体，经脉初通' },
  { v: 3, name: '筑基', short: '基', lore: '丹田凝光，根基已成' },
  { v: 4, name: '金丹', short: '丹', lore: '金丹九转，寿元大增' },
  { v: 5, name: '元婴', short: '婴', lore: '婴儿现形，元神出窍' },
  { v: 6, name: '化神', short: '神', lore: '神魂凝实，可游太虚' },
  { v: 7, name: '炼虚', short: '虚', lore: '虚空生裂，一念千里' },
  { v: 8, name: '合体', short: '合', lore: '双影归一，法体大成' },
  { v: 9, name: '大乘', short: '乘', lore: '万丈金光，道基圆满' },
  { v: 10, name: '渡劫', short: '劫', lore: '天雷磅落，生死一线' },
  { v: 11, name: '地仙', short: '地', lore: '脱离凡胎，位列仙班' },
  { v: 12, name: '天仙', short: '天', lore: '九彩霞光，遨游八荒' },
  { v: 13, name: '金仙', short: '仙', lore: '法则缠身，言出法随' },
  { v: 14, name: '大罗金仙', short: '罗', lore: '星河倒卷，过去未来' },
  { v: 15, name: '道祖', short: '祖', lore: '混沌旋涌，万道归宗' },
  { v: 16, name: '混沌', short: '混', lore: '重开天地，创世而立' }
]

export const EVENTS = [
  { id: 'rain', name: '天降灵雨', desc: '下次生成金丹' },
  { id: 'demon', name: '心魔入侵', desc: '五步未合，一阶退转' },
  { id: 'relic', name: '上古遗迹', desc: '灵盘临时扩列十步' },
  { id: 'enlighten', name: '顿悟', desc: '连破三次，新灵升阶' },
  { id: 'tribulation', name: '天劫', desc: '锁定一格，三步方解' },
  { id: 'possess', name: '夺舍', desc: '灵盘将满，低阶被夺' }
]

export const GONGFA = [
  { id: 'jindan', name: '九转金丹诀', desc: '成金丹时30%另生炼气' },
  { id: 'taixu', name: '太虚心法', desc: '每步15%不生新灵' },
  { id: 'xiemo', name: '血魔功', desc: '功德×1.5，每六步退阶' },
  { id: 'qingyun', name: '青云诀', desc: '开局多两缕灵气' },
  { id: 'taiji', name: '太极图', desc: '首次坐化自动续命' },
  { id: 'hunyuan', name: '混元功', desc: '新灵升阶概率+15%' },
  { id: 'xingxiu', name: '星宿诀', desc: '每十步自动合一' },
  { id: 'wangqing', name: '太上忘情', desc: '心魔天劫不再临身' }
]

export const FABAO = [
  { id: 'qiankun', name: '乾坤袋', short: '袋', cd: 3, desc: '随机一灵升一阶' },
  { id: 'dingfeng', name: '定风珠', short: '珠', cd: 5, desc: '下次滑动不生新灵' },
  { id: 'lunhui', name: '轮回镜', short: '镜', cd: 1, desc: '最低阶诸灵合一' },
  { id: 'zhanxian', name: '斩仙飞刀', short: '刀', cd: 2, desc: '斩去最低阶一灵' }
]

// 宗门弟子
export const DISCIPLES = [
  { id: 'dan', name: '炼丹弟子', short: '丹', cost: 600, desc: '生成灵气等级偏高' },
  { id: 'jian', name: '剑修弟子', short: '剑', cost: 800, desc: '合成时10%再合一' },
  { id: 'zhen', name: '阵法弟子', short: '阵', cost: 1000, desc: '满盘时概率腾格' }
]

export const BREAK_LEVELS = [4, 5, 6, 9, 10, 11, 13, 15]

export const UPGRADES = [
  { id: 'chushi', name: '初始灵气', max: 5, cost: function (lv) { return 300 * (lv + 1) }, desc: '提升初始生成上限' },
  { id: 'rongliang', name: '灵盘容量', max: 2, cost: function (lv) { return lv === 0 ? 1200 : 3000 }, desc: '4x4→5x4→5x5' },
  { id: 'jiachi', name: '功德加成', max: 5, cost: function (lv) { return 400 * (lv + 1) }, desc: '每级结算功德+10%' },
  { id: 'fabao', name: '法宝槽', max: 2, cost: function (lv) { return lv === 0 ? 800 : 2000 }, desc: '多携带一件法宝' },
  { id: 'lingshou', name: '灵兽伙伴', max: 2, cost: function (lv) { return 1500 * (lv + 1) }, desc: '开局自动合一' }
]

export const SAVE_KEY = '__wdcs_save_v1__'
export const GONGFA_KEY = '__wdcs_gongfa__'
export const PICK_KEY = '__wdcs_pick__'

export function defaultSave () {
  return {
    ver: 1,
    gongde: 0,
    totalGongde: 0,
    shisu: 1,
    bestRealm: 1,
    runs: 0,
    up: { chushi: 0, rongliang: 0, jiachi: 0, fabao: 0, lingshou: 0 },
    sect: { members: [] },
    codex: { realms: [1], events: [] },
    fabaoCd: { qiankun: 0, dingfeng: 0, lunhui: 0, zhanxian: 0 },
    memory: []
  }
}

export function realmOf (v) {
  if (v < 1) v = 1
  if (v > 16) v = 16
  return REALMS[v - 1]
}

export function randInt (n) {
  return Math.floor(Math.random() * n)
}

export function createGrid (cols, rows) {
  const g = []
  const n = cols * rows
  for (let i = 0; i < n; i++) g.push({ v: 0, lock: 0, cls: 'ae', txt: '' })
  return g
}

export function cloneGrid (grid) {
  const g = []
  for (let i = 0; i < grid.length; i++) {
    g.push({ v: grid[i].v, lock: grid[i].lock, cls: grid[i].cls, txt: grid[i].txt })
  }
  return g
}

// 刷新显示字段。cols 决定格子尺寸样式前缀（4列→a，5列→b）
export function paint (grid, cols) {
  const p = cols === 5 ? 'b' : 'a'
  for (let i = 0; i < grid.length; i++) {
    const it = grid[i]
    if (it.v > 0) {
      it.cls = it.lock > 0 ? (p + it.v + 'k') : (p + it.v)
      it.txt = realmOf(it.v).short
    } else {
      it.cls = p + 'e'
      it.txt = ''
    }
  }
  return grid
}

function lineIdx (dir, k, cols, rows) {
  const idxs = []
  let i
  if (dir === 'left') {
    for (i = 0; i < cols; i++) idxs.push(k * cols + i)
  } else if (dir === 'right') {
    for (i = cols - 1; i >= 0; i--) idxs.push(k * cols + i)
  } else if (dir === 'up') {
    for (i = 0; i < rows; i++) idxs.push(i * cols + k)
  } else {
    for (i = rows - 1; i >= 0; i--) idxs.push(i * cols + k)
  }
  return idxs
}

/**
 * 一次滑动：移动 + 合并 + 锁定递减 + 刷新显示，全程单趟遍历
 * lock>0 的格子（天劫锁定）不可移动，并作为分段边界
 */
export function slide (grid, dir, cols, rows) {
  const g = []
  for (let i = 0; i < grid.length; i++) {
    g.push({ v: grid[i].v, lock: grid[i].lock, cls: '', txt: '' })
  }
  let moved = false
  let merges = 0
  let mergedMax = 0
  const n = cols > rows ? cols : rows
  for (let k = 0; k < n; k++) {
    if (dir === 'left' || dir === 'right') {
      if (k >= rows) continue
    } else if (k >= cols) continue
    const idxs = lineIdx(dir, k, cols, rows)
    const segs = []
    let cur = []
    for (let i = 0; i < idxs.length; i++) {
      const idx = idxs[i]
      if (g[idx].lock > 0) {
        if (cur.length > 0) { segs.push(cur); cur = [] }
      } else {
        cur.push(idx)
      }
    }
    if (cur.length > 0) segs.push(cur)
    for (let s = 0; s < segs.length; s++) {
      const seg = segs[s]
      const vals = []
      for (let i = 0; i < seg.length; i++) {
        if (g[seg[i]].v > 0) vals.push(g[seg[i]].v)
      }
      const out = []
      let p = 0
      while (p < vals.length) {
        if (p + 1 < vals.length && vals[p] === vals[p + 1] && vals[p] < 16) {
          const nv = vals[p] + 1
          out.push(nv)
          merges++
          if (nv > mergedMax) mergedMax = nv
          p += 2
        } else {
          out.push(vals[p])
          p += 1
        }
      }
      for (let j = 0; j < seg.length; j++) {
        const nv = j < out.length ? out[j] : 0
        if (g[seg[j]].v !== nv) moved = true
        g[seg[j]].v = nv
      }
    }
  }
  // 锁定递减 + 刷新显示，与上面合并为同一趟尾部处理
  const p = cols === 5 ? 'b' : 'a'
  for (let i = 0; i < g.length; i++) {
    if (g[i].lock > 0) g[i].lock = g[i].lock - 1
    const it = g[i]
    if (it.v > 0) {
      it.cls = it.lock > 0 ? (p + it.v + 'k') : (p + it.v)
      it.txt = realmOf(it.v).short
    } else {
      it.cls = p + 'e'
      it.txt = ''
    }
  }
  return { grid: g, moved: moved, merges: merges, mergedMax: mergedMax }
}

export function empties (grid) {
  const a = []
  for (let i = 0; i < grid.length; i++) {
    if (grid[i].v === 0) a.push(i)
  }
  return a
}

export function maxV (grid) {
  let m = 0
  for (let i = 0; i < grid.length; i++) {
    if (grid[i].v > m) m = grid[i].v
  }
  return m
}

export function usedCount (grid) {
  let n = 0
  for (let i = 0; i < grid.length; i++) {
    if (grid[i].v > 0) n++
  }
  return n
}

export function canMove (grid, cols, rows) {
  if (empties(grid).length > 0) return true
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c
      if (grid[i].lock > 0) continue
      if (c + 1 < cols) {
        const j = i + 1
        if (grid[j].lock === 0 && grid[i].v === grid[j].v) return true
      }
      if (r + 1 < rows) {
        const j = i + cols
        if (grid[j].lock === 0 && grid[i].v === grid[j].v) return true
      }
    }
  }
  return false
}

export function rollSpawn (maxLevel, enlighten, hunyuan) {
  const r = Math.random() * 100
  let lv = 1
  if (maxLevel >= 4 && r < 2) lv = 4
  else if (maxLevel >= 3 && r < 10) lv = 3
  else if (r < 40) lv = 2
  if (enlighten && lv < 16) lv += 1
  else if (hunyuan && lv < 16 && Math.random() * 100 < 15) lv += 1
  const cap = maxLevel + 1
  if (lv > cap) lv = cap
  if (lv > 16) lv = 16
  return lv
}

export function spawnMax (chushiLv) {
  if (chushiLv >= 5) return 4
  if (chushiLv >= 3) return 3
  return 2
}

// 灵盘容量等级 → 基准列数 / 行数
export function boardSize (rongliangLv) {
  if (rongliangLv >= 2) return { cols: 5, rows: 5 }
  if (rongliangLv === 1) return { cols: 5, rows: 4 }
  return { cols: 4, rows: 4 }
}

// 上古遗迹：临时加一列（4列→5列），多出的格子留空
export function expandCols (grid, cols, rows) {
  const nc = cols + 1
  const g = []
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const s = grid[r * cols + c]
      g.push({ v: s.v, lock: s.lock, cls: '', txt: '' })
    }
    g.push({ v: 0, lock: 0, cls: '', txt: '' })
  }
  return { grid: paint(g, nc), cols: nc, rows: rows }
}

// 遗迹结束：收回一列，无法容纳的灵体消散
export function shrinkCols (grid, cols, rows) {
  const nc = cols - 1
  const g = []
  for (let r = 0; r < rows; r++) {
    const line = []
    for (let c = 0; c < cols; c++) {
      const s = grid[r * cols + c]
      if (s.v > 0) line.push({ v: s.v, lock: s.lock })
    }
    for (let c = 0; c < nc; c++) {
      if (c < line.length) {
        g.push({ v: line[c].v, lock: line[c].lock, cls: '', txt: '' })
      } else {
        g.push({ v: 0, lock: 0, cls: '', txt: '' })
      }
    }
  }
  return { grid: paint(g, nc), cols: nc, rows: rows }
}

export function calcGongde (best, merges, events, jiachiLv, xiemo) {
  let g = best * 100 + merges * 10 + events * 50
  g = g * (1 + 0.1 * jiachiLv)
  if (xiemo) g = g * 1.5
  return Math.floor(g)
}

export function pickGongfa (owned) {
  const pool = []
  for (let i = 0; i < GONGFA.length; i++) {
    if (!owned[GONGFA[i].id]) pool.push(GONGFA[i])
  }
  const out = []
  for (let n = 0; n < 3 && pool.length > 0; n++) {
    const i = randInt(pool.length)
    out.push(pool[i])
    pool.splice(i, 1)
  }
  return out
}

export function autoMergeOne (grid, cols) {
  const g = cloneGrid(grid)
  let target = 0
  for (let lv = 1; lv <= 15; lv++) {
    let c = 0
    for (let i = 0; i < g.length; i++) {
      if (g[i].v === lv && g[i].lock === 0) c++
    }
    if (c >= 2) { target = lv; break }
  }
  if (target === 0) return null
  const idxs = []
  for (let i = 0; i < g.length; i++) {
    if (g[i].v === target && g[i].lock === 0) idxs.push(i)
  }
  const a = idxs[randInt(idxs.length)]
  let b = -1
  for (let i = 0; i < idxs.length; i++) {
    if (idxs[i] !== a) { b = idxs[i]; break }
  }
  if (b < 0) return null
  g[a].v = target + 1
  g[b].v = 0
  return paint(g, cols)
}

export function clearLowest (grid, count, cols) {
  const g = cloneGrid(grid)
  let removed = 0
  for (let lv = 1; lv <= 16 && removed < count; lv++) {
    for (let i = 0; i < g.length && removed < count; i++) {
      if (g[i].v === lv && g[i].lock === 0) {
        g[i].v = 0
        removed++
      }
    }
  }
  return paint(g, cols)
}

export function mergeLowestAll (grid, cols) {
  const g = cloneGrid(grid)
  let low = 0
  for (let lv = 1; lv <= 16; lv++) {
    let c = 0
    for (let i = 0; i < g.length; i++) {
      if (g[i].v === lv) c++
    }
    if (c >= 2) { low = lv; break }
  }
  if (low === 0) return null
  const idxs = []
  for (let i = 0; i < g.length; i++) {
    if (g[i].v === low && g[i].lock === 0) idxs.push(i)
  }
  if (idxs.length < 2) return null
  for (let i = 1; i < idxs.length; i++) g[idxs[i]].v = 0
  g[idxs[0]].v = low + 1
  return paint(g, cols)
}

export function upgradeOne (grid, cols) {
  const g = cloneGrid(grid)
  const idxs = []
  for (let i = 0; i < g.length; i++) {
    if (g[i].v > 0 && g[i].v < 16 && g[i].lock === 0) idxs.push(i)
  }
  if (idxs.length === 0) return null
  const i = idxs[randInt(idxs.length)]
  g[i].v = g[i].v + 1
  return paint(g, cols)
}

export function downgradeOne (grid, cols) {
  const g = cloneGrid(grid)
  const idxs = []
  for (let i = 0; i < g.length; i++) {
    if (g[i].v > 1 && g[i].lock === 0) idxs.push(i)
  }
  if (idxs.length === 0) return null
  const i = idxs[randInt(idxs.length)]
  g[i].v = g[i].v - 1
  return paint(g, cols)
}

export function lockOne (grid, steps, cols) {
  const g = cloneGrid(grid)
  const cand = []
  const blank = []
  for (let i = 0; i < g.length; i++) {
    if (g[i].v > 0 && g[i].lock === 0) cand.push(i)
    if (g[i].v === 0) blank.push(i)
  }
  const pool = cand.length > 0 ? cand : blank
  if (pool.length === 0) return null
  g[pool[randInt(pool.length)]].lock = steps
  return paint(g, cols)
}
